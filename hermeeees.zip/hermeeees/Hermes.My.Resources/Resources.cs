using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace Hermes.My.Resources;

[StandardModule]
[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
[DebuggerNonUserCode]
[CompilerGenerated]
[HideModuleName]
internal sealed class Resources
{
	private static ResourceManager resourceMan;

	private static CultureInfo resourceCulture;

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static ResourceManager ResourceManager
	{
		get
		{
			if (object.ReferenceEquals(resourceMan, null))
			{
				ResourceManager resourceManager = new ResourceManager("Hermes.Resources", typeof(Resources).Assembly);
				resourceMan = resourceManager;
			}
			return resourceMan;
		}
	}

	[EditorBrowsable(EditorBrowsableState.Advanced)]
	internal static CultureInfo Culture
	{
		get
		{
			return resourceCulture;
		}
		set
		{
			resourceCulture = value;
		}
	}

	internal static Bitmap activity_monitor_warning
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("activity_monitor_warning", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap address_book_add_32
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("address_book_add_32", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap address_book_new
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("address-book-new", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap ajuste_product
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("ajuste-product", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap almacenInf
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("almacenInf", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Antrepo_Container_2_Box_1
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Antrepo-Container-2-Box-1", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Antrepo_Container_2_Cargo_1
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Antrepo-Container-2-Cargo-1", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Box_Add
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Box_Add", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Button_Check
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Button_Check", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Button_White_Load
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Button_White_Load", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap close_32
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("close_32", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap descarga
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("descarga", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Document_Checklist
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Document_Checklist", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap document_edit
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("document-edit", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap document_new
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("document-new", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap document_open_folder
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("document-open-folder", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap document_preview_archive
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("document-preview-archive", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap document_print_direct
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("document-print-direct", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap document_print_direct1
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("document-print-direct1", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap document_swap
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("document-swap", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap edit_guides
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("edit-guides", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap enter_product
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("enter-product", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap etrans2
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("etrans2", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap excel_1
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("excel_1", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap flag_blue
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("flag-blue", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap flag_red
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("flag-red", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap flag_yellow
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("flag-yellow", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap games_difficult
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("games-difficult", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap go_down
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("go-down", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap go_jump_definition
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("go-jump-definition", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap go_up
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("go-up", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap home_go_32
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("home_go_32", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap info_button_32
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("info_button_32", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap info_button_321
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("info_button_321", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap ktorrent
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("ktorrent", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Light_Bulb_On
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Light_Bulb_On", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap logo_etrans
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("logo_etrans", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Logo_hermes_3
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Logo_hermes_3", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Logo_hermes_31
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Logo_hermes_31", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap logoArea
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("logoArea", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap logoArea1
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("logoArea1", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap out_product
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("out-product", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap page_table_32
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("page_table_32", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap Ruler
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("Ruler", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap run_build
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("run-build", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap utilities_file_archiver
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("utilities-file-archiver", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap vcs_conflicting
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("vcs-conflicting", resourceCulture));
			return (Bitmap)objectValue;
		}
	}

	internal static Bitmap view_calendar_tasks
	{
		get
		{
			object objectValue = RuntimeHelpers.GetObjectValue(ResourceManager.GetObject("view-calendar-tasks", resourceCulture));
			return (Bitmap)objectValue;
		}
	}
}
