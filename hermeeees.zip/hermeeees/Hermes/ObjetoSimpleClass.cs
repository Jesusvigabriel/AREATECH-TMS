namespace Hermes;

public class ObjetoSimpleClass
{
	public int id;

	public string texto;

	public string status;

	public object json;
}
