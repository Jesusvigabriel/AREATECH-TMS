using System.Diagnostics;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyTitle("Hermes")]
[assembly: AssemblyDescription("Sistema de Ruteo")]
[assembly: AssemblyCompany("Area54")]
[assembly: AssemblyProduct("Hermes")]
[assembly: AssemblyCopyright("Copyright ©  2014")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("789bc34f-180a-47a7-9f7b-30f3b160579f")]
[assembly: AssemblyFileVersion("20.0.11")]
[assembly: NeutralResourcesLanguage("es-AR")]
[assembly: AssemblyVersion("20.0.1.0")]
