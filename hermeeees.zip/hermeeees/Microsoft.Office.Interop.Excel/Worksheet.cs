using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Microsoft.Office.Interop.Excel;

[ComImport]
[CompilerGenerated]
[CoClass(typeof(object))]
[Guid("000208D8-0000-0000-C000-000000000046")]
[TypeIdentifier]
public interface Worksheet : _Worksheet, DocEvents_Event
{
}
