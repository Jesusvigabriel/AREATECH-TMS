using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Microsoft.Office.Interop.Excel;

[ComImport]
[CompilerGenerated]
[Guid("00024412-0000-0000-C000-000000000046")]
[InterfaceType(2)]
[TypeIdentifier]
public interface WorkbookEvents
{
}
