using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Microsoft.Office.Interop.Excel;

[ComImport]
[CompilerGenerated]
[Guid("000208D5-0000-0000-C000-000000000046")]
[CoClass(typeof(object))]
[TypeIdentifier]
public interface Application : _Application, AppEvents_Event
{
}
