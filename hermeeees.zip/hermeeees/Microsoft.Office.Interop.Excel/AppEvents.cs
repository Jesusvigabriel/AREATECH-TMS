using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Microsoft.Office.Interop.Excel;

[ComImport]
[CompilerGenerated]
[InterfaceType(2)]
[Guid("00024413-0000-0000-C000-000000000046")]
[TypeIdentifier]
public interface AppEvents
{
}
