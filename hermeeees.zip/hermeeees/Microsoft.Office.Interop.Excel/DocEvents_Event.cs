using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Microsoft.Office.Interop.Excel;

[ComImport]
[CompilerGenerated]
[ComEventInterface(typeof(DocEvents), typeof(DocEvents))]
[TypeIdentifier("00020813-0000-0000-c000-000000000046", "Microsoft.Office.Interop.Excel.DocEvents_Event")]
public interface DocEvents_Event
{
}
