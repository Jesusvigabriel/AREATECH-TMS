using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Microsoft.Office.Interop.Excel;

[ComImport]
[CompilerGenerated]
[ComEventInterface(typeof(WorkbookEvents), typeof(WorkbookEvents))]
[TypeIdentifier("00020813-0000-0000-c000-000000000046", "Microsoft.Office.Interop.Excel.WorkbookEvents_Event")]
public interface WorkbookEvents_Event
{
}
